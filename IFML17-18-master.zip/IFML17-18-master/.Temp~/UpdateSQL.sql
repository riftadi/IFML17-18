-- Notifications [ent1]
alter table "public"."notifications"  add column  "contenttitle"  text;


