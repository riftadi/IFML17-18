-- Notifications [ent1]
alter table "public"."notifications"   drop column  "content";
